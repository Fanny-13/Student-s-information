package com.company;

public class Student {
    String Stu_Name;
    String Stu_Year;
    double Stu_GPA;

    public String getName() {
        return Stu_Name;
    }
    
    public void setName(String name) {
        this.Stu_Name = name;
    }

    public String getYear() {
        return Stu_Year;
    }

    public void setYear (String year) {
        this.Stu_Year = year;
    }
    
    public double getGPA() {
        return Stu_GPA;
    }

    public void setGPA (double GPA) {
        this.Stu_GPA = GPA;
    }

    public void printStudent() {
        System.out.println(getName());
        System.out.println(getYear());
        System.out.println(getGPA());
    }

    public Student(String Stu_Name, String Stu_Year, double Stu_GPA) {
        setName(Stu_Name);
        setYear(Stu_Year);
        setGPA(Stu_GPA);
    }

    @Override
    public String toString() {
        return String.format(Stu_Name + ", " + Stu_Year + ", " + Stu_GPA);
    }
}


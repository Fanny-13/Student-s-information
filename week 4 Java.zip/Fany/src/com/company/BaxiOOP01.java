/*
* Author: Fanny Baxi
* Course: cpsc24500
* Date: 09/07/2020
* Discription:- This program is about printing the Students name, Students
Academic Year, Students GPA, Students Info; Exit.
*
*/

package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class BaxiOOP01 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<Student>();
        String Stu_Name = "";
        String Stu_Year = "";
        double Stu_GPA = 0.0;
        int selection;

        // The main loop
        while (true) {
            // Display the current options
            System.out.println("");
            System.out.println("1. Enter the Students name ");
            System.out.println("2. Enter the Students Academic Year ");
            System.out.println("3. Enter the Students GPA ");
            System.out.println("4. Display Students Info");
            System.out.println("5. Exit");
            System.out.println();
            do {
                System.out.print("Please enter which number you want to answer: ");
                selection = input.nextInt();
                switch (selection) {
                    case 1:
                        System.out.print("Enter Students Name: ");
                        Stu_Name = input.next();
                        break;
                    case 2:
                        System.out.print("Enter Students Academic Year: ");
                        Stu_Year = input.next();
                        if (Stu_Year.contains("freshman") || Stu_Year.contains("sophomore") || Stu_Year.contains("junior") || Stu_Year.contains("senior")) {
                        } else{
                            System.out.println ( "Invalid Entry. Please use all the lower case." );
                            Stu_Year = null;
                        }
                        break;

                    case 3:
                        System.out.print("Enter Students GPA: ");
                        Stu_GPA = input.nextDouble();
                        // Get the correct information from the user
                        // Do not acceot any invalid numbers
                        if (Stu_GPA < 0.0) {
                            System.out.println("This is not a valid GPA");
                        } else if (Stu_GPA > 4.0) {
                            System.out.println("This is not a valid GPA");
                        } else {
                            System.out.println("");
                        }
                        break;
                    // Display more information from students
                    case 4:
                        System.out.println("Display Students Info: ");
                        System.out.println("name: " + Stu_Name);
                        System.out.println("year: " + Stu_Year);
                        System.out.println("GPA: " + Stu_GPA);
                        break;
                    case 5:
                        System.out.print("Exit");
                        System.exit(0);
                        break;
                    default:
                        System.err.println("Unrecognized option");
                        break;
                }
                Student myStu = new Student(Stu_Name, Stu_Year, Stu_GPA);
                students.add(myStu);

            } while (selection != 5);
        }
    }
}
